INDIAN FAST FOOD & CAFE - WEBSITE

This folder contains index.html, ready for static hosting.

QUICK DEPLOY:
1. Open Netlify Drop in a browser: https://app.netlify.com/drop
2. Upload the ZIP file or the folder contents.
3. Netlify will give you a public website link.

The current site includes:
- Indian Fast Food & Cafe branding image
- Demo menu and prices
- Cart
- Customer name/mobile/address
- Cash on Delivery / UPI option
- WhatsApp ordering to 9125428413
- 5 KM free delivery / 15-minute delivery banner

Menu prices are demo prices and can be changed in index.html.
